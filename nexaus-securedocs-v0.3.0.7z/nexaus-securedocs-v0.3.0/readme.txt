=== Nexaus SecureDocs ===
Contributors: nexausteam
Requires at least: 6.0
Tested up to: 6.6
Stable tag: 0.3.0
License: GPLv2 or later

Nexaus SecureDocs is an AI-assisted document generator for cybersecurity compliance (ISO27001, Cyber Essentials, GDPR). Supports Groq or OpenAI providers. Live model picker + Test Connection.

== Shortcodes ==
[nsd_dashboard]
[nsd_generate type="policy" template="iso27001-information-security-policy"]

== Installation ==
1. Upload the plugin zip in WP Admin > Plugins > Add New > Upload.
2. Activate the plugin.
3. Go to SecureDocs > Settings, choose AI Provider, paste the API key, click "Fetch Models", pick one, Save.
4. Optionally click "Test Connection".
5. Create a page "App" and add [nsd_dashboard] or [nsd_generate].
