=== Nexaus SecureDocs ===
Stable tag: 0.3.1
Clean HTML output only. Unified admin menu with submenus. Groq/OpenAI support with live model picker + Test Connection.
Update: Upload ZIP and click “Replace current with uploaded” to overwrite previous version.
